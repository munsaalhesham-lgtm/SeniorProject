package com.example.alphabet.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.alphabet.R;
import com.example.alphabet.Tools;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity  extends AppCompatActivity {
    private Button startgame , register, Enter,logout,choose;
    private Database database;
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // database = new Database(MainActivity.this);
        startgame =  findViewById(R.id.startgame);
        register= findViewById(R.id.register);
        Enter= findViewById(R.id.Enter);
        logout= findViewById(R.id.logout);
        choose= findViewById(R.id.choose);
        ImageView imageView=findViewById(R.id.imageView7);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            Tools.enableMyLocationIfPermitted(this);
        }


        if (SettingUtility.isActivited(this)){
            register.setVisibility(View.GONE);
            Enter.setVisibility(View.GONE);
            logout.setVisibility(View.VISIBLE);
            choose.setVisibility(View.VISIBLE);
        }else {
            register.setVisibility(View.VISIBLE);
            Enter.setVisibility(View.VISIBLE);
            logout.setVisibility(View.GONE);
            choose.setVisibility(View.GONE);
        }

        logout.setOnClickListener(v->{
            SettingUtility.clearSettings(this);
            SettingUtility.setActivited(this,false);
            register.setVisibility(View.VISIBLE);
            Enter.setVisibility(View.VISIBLE);
            logout.setVisibility(View.GONE);
            choose.setVisibility(View.GONE);
        });
        choose.setOnClickListener(v->{
            startActivity(new Intent(this,CharacterActivity.class));
        });
        database = new Database(this);
        database.getReadableDatabase();
        database.getWritableDatabase();

        startgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Startgame();
            }
        });
        //RegisterActivity
        register.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                register();
            }
        });
        Enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Enter();
            }
        });

        int resID=getResources().getIdentifier("main_interface1", "raw", getPackageName());
        int resID2=getResources().getIdentifier("main_interface3", "raw", getPackageName());

        mediaPlayer = MediaPlayer.create(this,resID);
        mediaPlayer.start();
        while (mediaPlayer.isPlaying()){
            Log.e("play","play");
        }
        mediaPlayer =MediaPlayer.create(this,resID2);
        mediaPlayer.start();


        imageView.setOnClickListener(v->{
            if (!mediaPlayer.isPlaying())
                mediaPlayer.start();

        });



    }


    public void Startgame(){
        if (SettingUtility.isActivited(getApplicationContext())) {
            Intent intent = new Intent(this, GameStageActivity.class);
            startActivity(intent);
        }else {
            Toast.makeText(this, "الرجاء تسجيل الدخول قبل البدء باللعب", Toast.LENGTH_SHORT).show();
        }
    }
    public void register(){
        Intent intent=new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
    public void Enter(){
        Intent intent=new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (SettingUtility.isActivited(this)){
            register.setVisibility(View.GONE);
            Enter.setVisibility(View.GONE);
            logout.setVisibility(View.VISIBLE);
            choose.setVisibility(View.VISIBLE);
        }else {
            register.setVisibility(View.VISIBLE);
            Enter.setVisibility(View.VISIBLE);
            logout.setVisibility(View.GONE);
            choose.setVisibility(View.GONE);
        }
    }
}

