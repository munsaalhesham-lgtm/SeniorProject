package com.example.alphabet;

import java.io.Serializable;

public class Letter implements Serializable {

    private int id;
    private String letter_sound;
    private String letter_img;
    private String lettr;
    private int letter_correct;

    public Letter(int id, String letter_sound, String letter_img, String lettr,int letter_correct) {
        this.id = id;
        this.letter_sound = letter_sound;
        this.letter_img = letter_img;
        this.lettr = lettr;
        this.letter_correct=letter_correct;
    }

    public int getLetter_correct() {
        return letter_correct;
    }

    public void setLetter_correct(int letter_correct) {
        this.letter_correct = letter_correct;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLetter_sound() {
        return letter_sound;
    }

    public void setLetter_sound(String letter_sound) {
        this.letter_sound = letter_sound;
    }

    public String getLetter_img() {
        return letter_img;
    }

    public void setLetter_img(String letter_img) {
        this.letter_img = letter_img;
    }

    public String getLettr() {
        return lettr;
    }

    public void setLettr(String lettr) {
        this.lettr = lettr;
    }
}
