package com.example.alphabet.ui;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.alphabet.R;

public class letters_table extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_letters_table);
    }

    Intent intent;
    public void onClick(View view) {


        intent = new Intent(letters_table.this, LetterChallengeActivity.class);
        startActivity(intent);

    }
}
