package com.example.alphabet.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.alphabet.R;
import com.example.alphabet.Word;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;
import com.example.alphabet.ui.adapters.SentenceAdapter;
import com.example.alphabet.ui.adapters.WordAdapter;

import java.util.ArrayList;

public class WordsActivity extends AppCompatActivity {
    private Button NextWor,previouseWor;
    private RecyclerView wordList;
    private ArrayList<Word> words=new ArrayList<>();
    private WordAdapter wordAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_words);
        NextWor=(Button)findViewById(R.id.NextS);
        previouseWor=(Button)findViewById(R.id.previouseS);
        wordList=findViewById(R.id.word_list);
        Database database=new Database(getApplicationContext());
        words=database.getWords(SettingUtility.getId(getApplicationContext()));
        if (words.size()==0){
            database.insertWord("lion","asd","أسد",1,"س");
            database.insertWord("bicycle","dragh","دراجة",2,"ج");
            database.insertWord("door","bab","باب",3,"ب");
            database.insertWord("crown","taj","تاج",4,"ت");
            database.insertWord("waves","amwaj","أمواج",1,"م");
            database.insertWord("head","raas","رأس",2,"أ");
            database.insertWord("roses","wrood","ورود",3,"ر");
            database.insertWord("qurans","quran","قرآن",4,"ق");
            database.insertWord("banana","mawz","موز",1,"م");
            database.insertWord("guard","hares","حارس",2,"ح");
            database.insertWord("boy","walad","ولد",3,"ل");
            database.insertWord("sand","rml","رمل",1,"م");
            database.insertWord("monkey","qrd","قرد",4,"ق");
            words=database.getWords(SettingUtility.getId(getApplicationContext()));
        }
        wordAdapter=new WordAdapter(words,this);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,3);
        wordList.setAdapter(wordAdapter);
        wordList.setLayoutManager(gridLayoutManager);

        NextWor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NextWor();
            }
        });
        previouseWor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                previouseWor();
            }
        });
        int resID=getResources().getIdentifier("word_stage", "raw", getPackageName());

        MediaPlayer mediaPlayer=MediaPlayer.create(this,resID);
        mediaPlayer.start();

    }
    public void NextWor(){
        Intent intent =new Intent (this, WordTutorialActivity.class);
        startActivity(intent);
        finish();

    }
    public void previouseWor(){
        Intent intent=new Intent(this, GameStageActivity.class);
        startActivity(intent);
        finish();

    }

}
