package com.example.alphabet.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.alphabet.Letter;
import com.example.alphabet.R;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;
import com.example.alphabet.ui.adapters.LetterAdapter;

import java.util.ArrayList;

public class LettersActivity extends AppCompatActivity {
    RecyclerView lettersList;
    ArrayList<Letter> letters=new ArrayList<>();
    LetterAdapter letterAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_letters);
        Database database=new Database(getApplicationContext());
        lettersList=findViewById(R.id.letters_list);
        letters.addAll(database.getLetters(SettingUtility.getId(getApplicationContext())));
        if (letters.size()==0){
            database.insertLetter("l1","a11","أ",1);
            database.insertLetter("l2","a22","ب",3);
            database.insertLetter("l3","a22","ت",4);
            database.insertLetter("l4","a22","ث",2);
            database.insertLetter("l5","a33","ج",3);
            database.insertLetter("l6","a33","ح",0);
            database.insertLetter("l7","a33","خ",3);
            database.insertLetter("l8","a44","د",0);
            database.insertLetter("l9","a44","ذ",3);
            database.insertLetter("l10","a55","ر",0);
            database.insertLetter("l11","a55","ز",3);
            database.insertLetter("l12","a66","س",0);
            database.insertLetter("l13","a66","ش",2);
            database.insertLetter("l14","a77","ص",0);
            database.insertLetter("l15","a77","ض",3);
            database.insertLetter("l16","a88","ط",0);
            database.insertLetter("l17","a88","ظ",3);
            database.insertLetter("l18","a99","ع",0);
            database.insertLetter("l19","a99","غ",3);
            database.insertLetter("l20","a1010","ف",3);
            database.insertLetter("l21","a1111","ق",4);
            database.insertLetter("l22","a1212","ك",1);
            database.insertLetter("l23","a1313","ل",0);
            database.insertLetter("l24","a1414","م",0);
            database.insertLetter("l25","a1515","ن",3);
            database.insertLetter("l26","a1616","ه",0);
            database.insertLetter("l27","a1717","و",0);
            database.insertLetter("l28","a1818","ي",0);
            letters.addAll(database.getLetters(SettingUtility.getId(getApplicationContext())));
        }

        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,3);
        letterAdapter=new LetterAdapter(letters,this);
        lettersList.setAdapter(letterAdapter);
        lettersList.setLayoutManager(gridLayoutManager);
        int resID=getResources().getIdentifier("letters_stage", "raw", getPackageName());

        MediaPlayer mediaPlayer=MediaPlayer.create(this,resID);
        mediaPlayer.start();

    }

}
