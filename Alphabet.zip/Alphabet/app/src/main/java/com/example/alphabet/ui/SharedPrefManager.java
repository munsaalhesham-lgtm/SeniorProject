package com.example.alphabet.ui;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
public class SharedPrefManager {
    private static SharedPrefManager instance;
    private static Context context;

    private static final String SHARED_PREF_NAME = "Main";
    private static final String IS_LOGGED_IN = "logged_in";
    private static final String USER = "user";

    private SharedPrefManager (Context context ){
        this.context = context ;
    }

    public static synchronized SharedPrefManager getInstance(Context context) {

        if (instance == null){
            instance = new SharedPrefManager(context);
        }
        return instance;

    }

    public boolean getIsLoggedIn (){

        SharedPreferences sharedprefrances  = context.getSharedPreferences(SHARED_PREF_NAME, context.MODE_PRIVATE);
        return sharedprefrances.getBoolean(IS_LOGGED_IN,false);
    }
    public void setIsLoggedIn( boolean value){
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(IS_LOGGED_IN, value);
        editor.commit();
    }
    public UserObject getUser (){
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, context.MODE_PRIVATE);
        String Json = sharedPreferences.getString(USER,"");
        UserObject userObject = new Gson().fromJson(Json,UserObject.class);
        return userObject;
    }


    public void setUser ( UserObject user){
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = new Gson().toJson(user);
        editor.putString(USER, json);
        editor.commit();
    }

}
