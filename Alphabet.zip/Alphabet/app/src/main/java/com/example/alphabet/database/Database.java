package com.example.alphabet.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.alphabet.Letter;
import com.example.alphabet.Sentence;
import com.example.alphabet.User;
import com.example.alphabet.Word;

import java.util.ArrayList;
import java.util.Random;


public class Database extends SQLiteOpenHelper {
    private Context context;
    private static final String database_name = "database.db";
    private static final int database_virsion = 1;

    // -- tables names --//
    private static final String Letters = "Letters";
    private static final String Letters_User = "Letters_user";
    private static final String Words_User = "Word_user";
    private static final String Words = "words";
    private static final String Sentences = "Sentences";
    private static final String Sentences_User = "Sentences_user";
    private static final String Stages = "stages";
    private static final String Substages = "Substages";
    private static final String Challenges = "Challenges";
    private static final String FavorateCharacter = "FavoriteCharacter";
    private static final String User = "User";
    private static final String Certificate = "certificate";

    private static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + Letters;
    private static final String SQL_DELETE_ENTRIES1 = "DROP TABLE IF EXISTS " + Letters_User;
    private static final String SQL_DELETE_ENTRIES2 = "DROP TABLE IF EXISTS " + Words;
    private static final String SQL_DELETE_ENTRIES22 = "DROP TABLE IF EXISTS " + Words_User;
    private static final String SQL_DELETE_ENTRIES3 = "DROP TABLE IF EXISTS " + Sentences;
    private static final String SQL_DELETE_ENTRIES33 = "DROP TABLE IF EXISTS " + Sentences_User;
    private static final String SQL_DELETE_ENTRIES4 = "DROP TABLE IF EXISTS " + Stages;
    private static final String SQL_DELETE_ENTRIES5 = "DROP TABLE IF EXISTS " + Substages;
    private static final String SQL_DELETE_ENTRIES6 = "DROP TABLE IF EXISTS " + Challenges;
    private static final String SQL_DELETE_ENTRIES7 = "DROP TABLE IF EXISTS " + FavorateCharacter;
    private static final String SQL_DELETE_ENTRIES8 = "DROP TABLE IF EXISTS " + User;
    private static final String SQL_DELETE_ENTRIES9 = "DROP TABLE IF EXISTS " + Certificate;

    private static final String TRUNCATE_ENTRIES = "DELETE FROM  " + Letters;
    private static final String TRUNCATE_ENTRIES1 = "DELETE FROM  " + Letters_User;
    private static final String TRUNCATE_ENTRIES2 = "DELETE FROM  " + Words;
    private static final String TRUNCATE_ENTRIES22 = "DELETE FROM  " + Words_User;
    private static final String TRUNCATE_ENTRIES3 = "DELETE FROM  " + Sentences;
    private static final String TRUNCATE_ENTRIES33 = "DELETE FROM  " + Sentences_User;
    private static final String TRUNCATE_ENTRIES4 = "DELETE FROM  " + Stages;
    private static final String TRUNCATE_ENTRIES5 = "DELETE FROM  " + Substages;
    private static final String TRUNCATE_ENTRIES6 = "DELETE FROM  " + Challenges;
    private static final String TRUNCATE_ENTRIES7 = "DELETE FROM  " + FavorateCharacter;
    private static final String TRUNCATE_ENTRIES8 = "DELETE FROM  " + User;
    private static final String TRUNCATE_ENTRIES9 = "DELETE FROM  " + Certificate;


    // ----------------------------------------- attributes names --------------------------------------------- //
    //--- IDs --- //
    private static final String Letter_ID = "L_ID";
    private static final String Letter_user_ID = "L_U_ID";
    private static final String Words_ID = "W_ID";
    private static final String Words_user_ID = "W_U_ID";
    private static final String Sentance_ID = "S_ID";
    private static final String Sentance_USER_ID = "S_U_ID";
    private static final String User_ID = "User_ID";
    private static final String FavCarecater_ID = "FavCharecater_ID";
    private static final String Stage_ID = "Stage_ID";
    private static final String Substage_ID = "Substage_ID";
    private static final String Challenge_ID = "Challenge_ID";
    //-- --//
    private static final String Letter_L = "Letter_L";
    private static final String Letter_part1 = "Letter_part1";
    private static final String USER_ID = "user_id";
    private static final String Letter_img = "Lettr_img";
    private static final String Letter_Sya = "Lettr_say";
    private static final String Letter_sound = "Lettr_sound";
    private static final String Letter_Correct = "Letter_Correct";
    private static final String Word_W = "Word_w";
    private static final String Word_miss = "Word_miss";
    private static final String Word_sound = "Word_sound";
    private static final String Word_part1 = "Word_part1";
    private static final String Word_correct = "Word_correct";
    private static final String Word_img = "Word_part2";
    private static final String Sentence_s = "Sentence_s";
    private static final String Sentence_w1 = "Sentence_W1";
    private static final String Sentence_img = "Sentence_img";
    private static final String Sentence_sound = "Sentence_sound";
    private static final String SENTENCE_CORRECT = "Sentence_correct";
    private static final String Sentences_miss = "Sentence_miss";
    private static final String S_wpart1 = "S_wpart1";
    private static final String S_wpart2 = "S_wpart2";
    private static final String S_wpart3 = "S_wpart3";
    private static final String S_wpart4 = "S_wpart4";
    private static final String Stage_tag = "Stage_tage";
    private static final String Substage_tag = "Substage_tag";
    private static final String Challenge_tag = "Challenge_tag";
    private static final String Certificate_img = "Certificate_img";
    private static final String Certifcate_tag = "Certificate_tag";
    private static final String FavCaracter_imge = "FavCaracter_imge";
    private static final String FavCaracter_name = "FavCaracter_name";
    private static final String User_password = "User_password";
    private static final String User_name = "User_name";
    private static final String User_birthdate = "User_birthdate";
    private static final String User_image = "User_image";
    private static final String User_stage = "User_stage";
    private static final String User_email = "User_email";
    // ----------------------------------------------creating the tables--------------------------------------------------- //

    private static final String CREAT_LETTERS_TABLE = "CREATE TABLE " + Letters +
            "(" + Letter_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            Letter_L + " VARCHAR(100) ," +
            Letter_sound + " VARCHAR(100) ," +
            Letter_Correct + " INTEGER ," +
            Letter_img + " VARCHAR(100)" +
            ");";
    private static final String CREAT_LETTERS_USER_TABLE = "CREATE TABLE " + Letters_User +
            "(" + Letter_user_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            User_ID + " INTEGER ," +
            Letter_part1 + " INTEGER ," +
            Letter_ID + " INTEGER" +
            ");";
    private static final String CREAT_WORDS_TABLE = "CREATE TABLE " +
            Words +
            "(" +
            Words_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            Word_W + " VARCHAR(200)," +
            Word_miss + " VARCHAR(200)," +
            Word_sound + " VARCHAR(200), " +
            Word_correct + " INTEGER, " +
            Word_img + " VARCHAR(200)" +
            ");";
    private static final String CREAT_WORD_USER_TABLE = "CREATE TABLE " + Words_User +
            "(" + Words_user_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            User_ID + " INTEGER ," +
            Word_part1 + " INTEGER ," +
            Words_ID + " INTEGER" +
            ");";
    private static final String CREAT_SENTENCES_TABLE = "CREATE TABLE " + Sentences +
            "(" +
            Sentance_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            Sentence_img + " VARCHAR(200)," +
            Sentence_sound + " VARCHARE(200)," +
            SENTENCE_CORRECT + " INTEGER," +
            Sentences_miss + " VARCHAR(200)," +
            Sentence_s + " VARCHAR(200)" +
            " );";
    private static final String CREAT_SENTENCES_USER_TABLE = "CREATE TABLE " + Sentences_User +
            "(" + Sentance_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            User_ID + " INTEGER ," +
            S_wpart1 + " INTEGER ," +
            Sentance_ID + " INTEGER" +
            ");";
    private static final String CREAT_USER_TABLE = "CREATE TABLE "
            + User +
            "(" +
            User_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            User_name + " VARCHAR(200)," +
            User_password + " VARCHAR(100)," +
            User_birthdate + " DATE ," +
            User_image + " mediumtext ," +
            User_stage + " INTEGER ," +
            User_email + " VARCHAR(200)" +
            ");";
    private static final String CREAT_FAVCHARACTER_TABLE = "CREATE TABLE "
            + FavorateCharacter +
            "(" +
            FavCarecater_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            FavCaracter_name + " VAVRCHAR," +
            FavCaracter_imge + " BLOB" +
            ")";
    private static final String CREAT_STAGES_TABLE = "CREATE TABLE "
            + Stages +
            "(" +
            Stage_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            Stage_tag + " BOOLEAN" +
            ");";
    private static final String CREAT_SUBSTAGES_TABLE = " CREATE TABLE "
            + Substages +
            "(" +
            Substage_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            Substage_tag + " BOOLEAN" +
            ");";
    private static final String CREAT_CHALLENGES_TABLE = "CREATE TABLE " +
            Challenges +
            "(" +
            Challenge_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            Challenge_tag + "BOOLEAN" +
            ");";
    private static final String CREAT_CERTIFCATE_TABLE = "CREATE TABLE " +
            Certificate +
            "(" +
            Certificate_img + " BLOB , " +
            Certifcate_tag + " BOOLEAN" +
            ");";
    //--------------------------------------------CONNECTION -----------------------------------------------------------//

    public void deleteAllValues() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(TRUNCATE_ENTRIES);
        db.execSQL(TRUNCATE_ENTRIES1);
        db.execSQL(TRUNCATE_ENTRIES2);
        db.execSQL(TRUNCATE_ENTRIES22);
        db.execSQL(TRUNCATE_ENTRIES3);
        db.execSQL(TRUNCATE_ENTRIES33);
        db.execSQL(TRUNCATE_ENTRIES4);
        db.execSQL(TRUNCATE_ENTRIES5);
        db.execSQL(TRUNCATE_ENTRIES6);
        db.execSQL(TRUNCATE_ENTRIES7);
        db.execSQL(TRUNCATE_ENTRIES8);
        db.execSQL(TRUNCATE_ENTRIES9);
    }

    //-- building DB -- //
    public Database(Context context) {
        super(context, database_name, null, database_virsion);
        this.context = context;
    }
    //--- promting queries to make the tables ---//


    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            Log.d("database", "history database being created");
            db.execSQL(CREAT_LETTERS_TABLE);
            db.execSQL(CREAT_LETTERS_USER_TABLE);
            db.execSQL(CREAT_WORDS_TABLE);
            db.execSQL(CREAT_WORD_USER_TABLE);
            db.execSQL(CREAT_SENTENCES_TABLE);
            db.execSQL(CREAT_SENTENCES_USER_TABLE);
            db.execSQL(CREAT_STAGES_TABLE);
            db.execSQL(CREAT_SUBSTAGES_TABLE);
            db.execSQL(CREAT_CHALLENGES_TABLE);
            db.execSQL(CREAT_CERTIFCATE_TABLE);
            db.execSQL(CREAT_FAVCHARACTER_TABLE);
            db.execSQL(CREAT_USER_TABLE);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL(SQL_DELETE_ENTRIES);
        db.execSQL(SQL_DELETE_ENTRIES1);
        db.execSQL(SQL_DELETE_ENTRIES2);
        db.execSQL(SQL_DELETE_ENTRIES22);
        db.execSQL(SQL_DELETE_ENTRIES3);
        db.execSQL(SQL_DELETE_ENTRIES33);
        db.execSQL(SQL_DELETE_ENTRIES4);
        db.execSQL(SQL_DELETE_ENTRIES5);
        db.execSQL(SQL_DELETE_ENTRIES6);
        db.execSQL(SQL_DELETE_ENTRIES7);
        db.execSQL(SQL_DELETE_ENTRIES8);
        db.execSQL(SQL_DELETE_ENTRIES9);
        onCreate(db);
    }


    public com.example.alphabet.User getCurrentUser(String emaill) {
        SQLiteDatabase db = this.getReadableDatabase();
        User user = null;
        Cursor cursor = db.rawQuery("select * from " + User + " where " + User_email + " = '" + emaill + "' order by " + User_ID + " DESC limit 1", null);
        Log.e("size", "select * from " + User + " where " + User_email + " = '" + emaill + "' order by " + User_ID + " DESC limit 1");
        while (cursor.moveToNext()) {
            user = new User(
                    cursor.getInt(cursor.getColumnIndex(User_ID)),
                    cursor.getString(cursor.getColumnIndex(User_name)),
                    cursor.getString(cursor.getColumnIndex(User_email)),
                    cursor.getString(cursor.getColumnIndex(User_password)),
                    cursor.getString(cursor.getColumnIndex(User_image)),
                    cursor.getString(cursor.getColumnIndex(User_birthdate)),
                    cursor.getInt(cursor.getColumnIndex(User_stage))
            );
        }
        cursor.close();
        return user;
    }

    //-----------------------rigester new user ---------------------//
    public Long registerUser(String name, String email, String password, int birthdate, String img) {
        SQLiteDatabase sqlitedatabase = getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put(User_name, name);
        contentvalues.put(User_email, email);
        contentvalues.put(User_password, password);
        contentvalues.put(User_birthdate, birthdate);
        contentvalues.put(User_image, img);
        sqlitedatabase.insert(User, null, contentvalues);

        SQLiteDatabase db = this.getReadableDatabase();
        User user = null;
        Cursor cursor = db.rawQuery("select * from " + User + " where " + User_email + " = '" + email + "' order by " + User_ID + " DESC limit 1", null);
        Log.e("size", cursor.getCount() + "");
        while (cursor.moveToNext()) {
            user = new User(
                    cursor.getInt(cursor.getColumnIndex(User_ID)),
                    cursor.getString(cursor.getColumnIndex(User_name)),
                    cursor.getString(cursor.getColumnIndex(User_email)),
                    cursor.getString(cursor.getColumnIndex(User_password)),
                    cursor.getString(cursor.getColumnIndex(User_image)),
                    cursor.getString(cursor.getColumnIndex(User_birthdate)),
                    cursor.getInt(cursor.getColumnIndex(User_stage))
            );
        }
        cursor.close();
        if (user != null)
            return (long) user.getId();
        else return 0L;
    }

    public void insertLetter(String letter_Sound, String letter_img, String letter, int correct) {
        SQLiteDatabase sqlitedatabase = getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put(Letter_img, letter_img);
        contentvalues.put(Letter_sound, letter_Sound);
        contentvalues.put(Letter_L, letter);
        contentvalues.put(Letter_Correct, correct);
        sqlitedatabase.insert(Letters, null, contentvalues);
    }

    public void insertWord(String word_Sound, String word_img, String word, int correct, String miss) {
        SQLiteDatabase sqlitedatabase = getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put(Word_img, word_img);
        contentvalues.put(Word_sound, word_Sound);
        contentvalues.put(Word_W, word);
        contentvalues.put(Word_correct, correct);
        contentvalues.put(Word_miss, miss);
        sqlitedatabase.insert(Words, null, contentvalues);
    }

    public void insertSentence(String sentence_Sound, String sentence_img, String sentence, int correct, String miss) {
        SQLiteDatabase sqlitedatabase = getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put(Sentence_img, sentence_img);
        contentvalues.put(Sentence_sound, sentence_Sound);
        contentvalues.put(Sentence_s, sentence);
        contentvalues.put(SENTENCE_CORRECT, correct);
        contentvalues.put(Sentences_miss, miss);
        sqlitedatabase.insert(Sentences, null, contentvalues);
    }

    public void insertLetterUser(int letter_id, int user_id, int part) {
        SQLiteDatabase sqlitedatabase = getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put(USER_ID, user_id);
        contentvalues.put(Letter_ID, letter_id);
        contentvalues.put(Letter_part1, part);
        sqlitedatabase.insert(Letters_User, null, contentvalues);
    }

    public void insertWordUser(int word_id, int user_id, int part) {
        SQLiteDatabase sqlitedatabase = getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put(USER_ID, user_id);
        contentvalues.put(Words_ID, word_id);
        contentvalues.put(Word_part1, part);
        sqlitedatabase.insert(Words_User, null, contentvalues);
    }

    public void insertSenteceUser(int sentence_id, int user_id, int part) {
        SQLiteDatabase sqlitedatabase = getWritableDatabase();
        ContentValues contentvalues = new ContentValues();
        contentvalues.put(USER_ID, user_id);
        contentvalues.put(Sentance_ID, sentence_id);
        contentvalues.put(S_wpart1, part);
        sqlitedatabase.insert(Sentences_User, null, contentvalues);
    }

    public void updateLetterStatus(int id, int user_id) {
        final SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Letter_part1, 1);
        db.update(Letters_User, contentValues, Letter_ID + " ='" + id + "' AND " + Letter_user_ID + " = '" + user_id + "'", null);
        db.close();
    }

    public void updateWordStatus(int id, int user_id) {
        final SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Word_part1, 1);
        db.update(Words_User, contentValues, Words_ID + " ='" + id + "' AND " + Words_user_ID + " = '" + user_id + "'", null);
        db.close();
    }

    public void updateSentenceStatus(int id, int user_id) {
        final SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(S_wpart1, 1);
        db.update(Sentences_User, contentValues, Sentance_ID + " ='" + id + "' AND " + Sentance_USER_ID + " = '" + user_id + "'", null);
        db.close();
    }

    public void updateUserStage(int stage, int user_id) {
        final SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(User_stage, stage);
        db.update(User, contentValues, User_ID + " ='" + user_id, null);
        db.close();
    }

    public ArrayList<Letter> getLetters(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Letter> letters = new ArrayList<>();
        Cursor cursor = db.rawQuery("select * from " + Letters + " order by " + Letter_ID + " ASC", null);
        while (cursor.moveToNext()) {
            letters.add(new Letter(
                    cursor.getInt(cursor.getColumnIndex(Letter_ID)),
                    cursor.getString(cursor.getColumnIndex(Letter_sound)),
                    cursor.getString(cursor.getColumnIndex(Letter_img)),
                    cursor.getString(cursor.getColumnIndex(Letter_L)),
                    cursor.getInt(cursor.getColumnIndex(Letter_Correct))
            ));
        }
        cursor.close();
        db.close();
        return letters;
    }

    public ArrayList<Word> getWords(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Word> words = new ArrayList<>();
        Cursor cursor = db.rawQuery("select * from " + Words + " order by " + Words_ID + " ASC", null);
        while (cursor.moveToNext()) {
            words.add(new Word(
                    cursor.getInt(cursor.getColumnIndex(Words_ID)),
                    cursor.getString(cursor.getColumnIndex(Word_sound)),
                    cursor.getString(cursor.getColumnIndex(Word_img)),
                    cursor.getString(cursor.getColumnIndex(Word_W)),
                    cursor.getInt(cursor.getColumnIndex(Word_correct)),
                    cursor.getString(cursor.getColumnIndex(Word_miss))
            ));
        }
        cursor.close();
        db.close();
        return words;
    }

    public Word getWord(int id) {
        if (id == 0)
            id = id + 1;
        SQLiteDatabase db = this.getReadableDatabase();
        Word words = null;
        Cursor cursor = db.rawQuery("select * from " + Words + " order by " + Words_ID + " ASC ", null);
        int i = 1;
        while (cursor.moveToNext()) {
            if (i == id)
                words = new Word(
                        cursor.getInt(cursor.getColumnIndex(Words_ID)),
                        cursor.getString(cursor.getColumnIndex(Word_sound)),
                        cursor.getString(cursor.getColumnIndex(Word_img)),
                        cursor.getString(cursor.getColumnIndex(Word_W)),
                        cursor.getInt(cursor.getColumnIndex(Word_correct)),
                        cursor.getString(cursor.getColumnIndex(Word_miss))
                );
            i++;
        }
        Log.e("sql", "select * from " + Words + " Where " + Words_ID + " <= " + id + " order by " + Words_ID + " ASC limit 1");
        cursor.close();
        db.close();
        return words;
    }

    public Letter getLetter(int id) {
        if (id == 0)
            id = id + 1;
        SQLiteDatabase db = this.getReadableDatabase();
        Letter letter = null;
        Cursor cursor = db.rawQuery("select * from " + Letters + " order by " + Letter_ID + " ASC ", null);
        int i = 1;
        while (cursor.moveToNext()) {
            if (i == id)
                letter = new Letter(
                        cursor.getInt(cursor.getColumnIndex(Letter_ID)),
                        cursor.getString(cursor.getColumnIndex(Letter_sound)),
                        cursor.getString(cursor.getColumnIndex(Letter_img)),
                        cursor.getString(cursor.getColumnIndex(Letter_L)),
                        cursor.getInt(cursor.getColumnIndex(Letter_Correct))
                );
            i++;
        }
        Log.e("sql", "select * from " + Words + " Where " + Words_ID + " <= " + id + " order by " + Words_ID + " ASC limit 1");
        cursor.close();
        db.close();
        return letter;
    }
   public Sentence getSentence(int id) {
        if (id == 0)
            id = id + 1;
        SQLiteDatabase db = this.getReadableDatabase();
        Sentence sentence = null;
        Cursor cursor = db.rawQuery("select * from " + Sentences + " order by " + Sentance_ID + " ASC ", null);
        int i = 1;
        while (cursor.moveToNext()) {
            if (i == id)
                sentence = new Sentence(
                        cursor.getInt(cursor.getColumnIndex(Sentance_ID)),
                        cursor.getString(cursor.getColumnIndex(Sentence_sound)),
                        cursor.getString(cursor.getColumnIndex(Sentence_img)),
                        cursor.getString(cursor.getColumnIndex(Sentence_s)),
                        cursor.getString(cursor.getColumnIndex(Sentences_miss)),
                        cursor.getInt(cursor.getColumnIndex(SENTENCE_CORRECT))
                );
            i++;
        }
        Log.e("sql", "select * from " + Words + " Where " + Words_ID + " <= " + id + " order by " + Words_ID + " ASC limit 1");
        cursor.close();
        db.close();
        return sentence;
    }

    public ArrayList<Sentence> getSentences(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Sentence> sentences = new ArrayList<>();
        Cursor cursor = db.rawQuery("select * from " + Sentences + " order by " + Sentance_ID + " ASC", null);
        while (cursor.moveToNext()) {
            sentences.add(new Sentence(
                    cursor.getInt(cursor.getColumnIndex(Sentance_ID)),
                    cursor.getString(cursor.getColumnIndex(Sentence_sound)),
                    cursor.getString(cursor.getColumnIndex(Sentence_img)),
                    cursor.getString(cursor.getColumnIndex(Sentence_s)),
                    cursor.getString(cursor.getColumnIndex(Sentences_miss)),
                    cursor.getInt(cursor.getColumnIndex(SENTENCE_CORRECT))
            ));
        }
        cursor.close();
        db.close();
        return sentences;
    }

    public int getLettersStatus(int id, int letter_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        int letters = -1;
        Cursor cursor = db.rawQuery("select * from " + Letters_User + " where " + USER_ID + " = '" + id + "' AND " + Letter_ID + " = '" + letter_id + "' order by " + Letter_ID + " Desc", null);
        while (cursor.moveToNext()) {
            letters = cursor.getInt(cursor.getColumnIndex(Letter_part1));
            Log.e("tag1", letters + "");
        }
        cursor.close();
        db.close();

        Log.e("tag", letters + "");
        return letters;
    }

    public int getWordsStatus(int id, int word_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        int words = -1;
        Cursor cursor = db.rawQuery("select * from " + Words_User + " where " + USER_ID + " = '" + id + "' AND " + Words_ID + " = '" + word_id + "' order by " + Words_ID + " Desc", null);
        while (cursor.moveToNext()) {
            words = cursor.getInt(cursor.getColumnIndex(Word_part1));
            Log.e("tag1", words + "");
        }
        cursor.close();
        db.close();

        Log.e("tag", words + "");
        return words;
    }

    public int getSentenceStatus(int id, int sentence_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        int wentence = -1;
        Cursor cursor = db.rawQuery("select * from " + Sentences_User + " where " + USER_ID + " = '" + id + "' AND " + Sentance_ID + " = '" + sentence_id + "' order by " + Sentance_ID + " Desc", null);
        while (cursor.moveToNext()) {
            wentence = cursor.getInt(cursor.getColumnIndex(S_wpart1));
            Log.e("tag1", wentence + "");
        }
        cursor.close();
        db.close();

        Log.e("tag", wentence + "");
        return wentence;
    }


}