package com.example.alphabet.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


import com.example.alphabet.R;
import com.example.alphabet.database.Database;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;



public class Game_Satge_Fragment extends Fragment {

    private Button Letter;
    private Button Word;
    private Button Sentence;
    private Database database ;

    public Game_Satge_Fragment() {
        // Required empty public constructor
    }


    public static Game_Satge_Fragment newInstance(String param1, String param2) {
        Game_Satge_Fragment fragment = new Game_Satge_Fragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        init_activity();
        init_events();
        init_views();
        View view =inflater.inflate(R.layout.activity_game_stage_interface, container, false);
        return view;
    }

    private void init_views() {

       // database = new Database(this);

    }
    private void init_events(){

    }
    private void init_activity(){

    }

}
