package com.example.alphabet;

import java.io.Serializable;

public class Sentence implements Serializable {
    private int id;
    private String sentence_sound;
    private String sentence_img;
    private String sentenc;
    private String sentence_miss;
    private int sentence_correct;

    public Sentence(int id, String sentence_sound, String sentence_img, String sentenc, String sentence_miss, int sentence_correct) {
        this.id = id;
        this.sentence_sound = sentence_sound;
        this.sentence_img = sentence_img;
        this.sentenc = sentenc;
        this.sentence_miss = sentence_miss;
        this.sentence_correct = sentence_correct;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSentence_sound() {
        return sentence_sound;
    }

    public void setSentence_sound(String sentence_sound) {
        this.sentence_sound = sentence_sound;
    }

    public String getSentence_img() {
        return sentence_img;
    }

    public void setSentence_img(String sentence_img) {
        this.sentence_img = sentence_img;
    }

    public String getSentenc() {
        return sentenc;
    }

    public void setSentenc(String sentenc) {
        this.sentenc = sentenc;
    }

    public String getSentence_miss() {
        return sentence_miss;
    }

    public void setSentence_miss(String sentence_miss) {
        this.sentence_miss = sentence_miss;
    }

    public int getSentence_correct() {
        return sentence_correct;
    }

    public void setSentence_correct(int sentence_correct) {
        this.sentence_correct = sentence_correct;
    }
}
