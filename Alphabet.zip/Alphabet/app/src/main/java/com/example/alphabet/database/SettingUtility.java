package com.example.alphabet.database;

import android.content.Context;
import android.content.SharedPreferences;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SettingUtility {
    public static String PREF_NAME = "CCIS";

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    private static SharedPreferences.Editor getEditor(Context context) {
        return getSharedPreferences(context).edit();
    }

    private static final String USERNAME = "USERNAME";

    public static String getUserName(Context context) {
        return getSharedPreferences(context).getString(USERNAME, null);
    }

    public static void setUserName(Context context, String nickname) {
        getEditor(context).putString(USERNAME, nickname).commit();
    }

    private static final String IMAGE = "IMAGE";

    public static String getImage(Context context) {
        return getSharedPreferences(context).getString(IMAGE, null);
    }

    public static void setImage(Context context, String nickname) {
        getEditor(context).putString(IMAGE, nickname).commit();
    }


    private static final String ID = "ID";

    public static int getId(Context context) {
        return getSharedPreferences(context).getInt(ID, 0);
    }

    public static void setId(Context context, int id) {
        getEditor(context).putInt(ID, id).commit();
    }


    private static final String EMAIL = "EMAIL";

    public static String getEmail(Context context) {
        return getSharedPreferences(context).getString(EMAIL, "");
    }

    public static void setEmail(Context context, String email) {
        getEditor(context).putString(EMAIL, email).commit();
    }


    private static final String PASSWORD = "PASSWORD";

    public static String getPassword(Context context) {
        return getSharedPreferences(context).getString(PASSWORD, null);
    }

    public static void setPassword(Context context, String password) {
        getEditor(context).putString(PASSWORD, password).commit();
    }

    private static final String ACTIVITED = "ACTIVITED";

    public static boolean isActivited(Context context) {
        return getSharedPreferences(context).getBoolean(ACTIVITED, false);
    }

    public static void setActivited(Context context, boolean state) {
        getEditor(context).putBoolean(ACTIVITED, state).commit();
    }


    public static void clearSettings(Context context) {
        getEditor(context).remove(USERNAME).commit();
        getEditor(context).remove(EMAIL).commit();
        getEditor(context).clear().apply();
        getEditor(context).clear().commit();
    }
}

