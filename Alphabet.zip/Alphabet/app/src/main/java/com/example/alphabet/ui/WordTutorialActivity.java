package com.example.alphabet.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alphabet.Letter;
import com.example.alphabet.R;
import com.example.alphabet.Word;

import java.text.DecimalFormat;
import java.util.Locale;

public class WordTutorialActivity extends AppCompatActivity {
    private Button wordSay;
    private Button NextLT;
    private Button repeat_btn,done_btn;
    TextToSpeech t1;
    boolean success=false;
    private MediaPlayer mediaPlayer;
    private Word word;
    private MyView view;
    public Paint mPaint;
    private boolean last;
    private MediaPlayer mediaPlayer2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_letter_tutorial);
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setDither(true);
        mPaint.setColor(Color.GREEN);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setStrokeWidth(24);
        wordSay = findViewById(R.id.letter_say);
        NextLT = (Button) findViewById(R.id.NextLT);
        repeat_btn = (Button) findViewById(R.id.button330);
        done_btn = (Button) findViewById(R.id.button30);
        TextView letter_tv=findViewById(R.id.letter_l);
        ImageView letterWrite_tv=findViewById(R.id.letter_write);
        ImageView voice_btn=findViewById(R.id.voice3);
        word = (Word) getIntent().getSerializableExtra("word");
        view = new MyView(this);
        ViewGroup layout = (ViewGroup) findViewById(R.id.container);
        view.setLayoutParams(new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT));
        view.setBackgroundColor(Color.WHITE);

        layout.addView(view);
        last = getIntent().getBooleanExtra("last",false);
        letterWrite_tv.requestFocus();
        letter_tv.setText(word.getWord());
        int resID = getResources().getIdentifier("write_on_word", "raw", getPackageName());
        int resID2 = getResources().getIdentifier(word.getWord_sound(), "raw", getPackageName());
        mediaPlayer = MediaPlayer.create(this,resID);
        mediaPlayer.start();
        mediaPlayer.setOnCompletionListener(mp -> {
            mp.stop();
            MediaPlayer mediaPlayer=MediaPlayer.create(this,resID2);
            mediaPlayer.start();
        });

        voice_btn.setOnClickListener(v->{

            mediaPlayer = MediaPlayer.create(this,resID2);
            mediaPlayer.start();

        });

        wordSay.setOnClickListener(v->{

            mediaPlayer = MediaPlayer.create(this,resID2);
            mediaPlayer.start();
        });
        repeat_btn.setOnClickListener(v->{
            mPaint = new Paint();
            mPaint.setAntiAlias(true);
            mPaint.setDither(true);
            mPaint.setColor(Color.GREEN);
            mPaint.setStyle(Paint.Style.FILL);
            mPaint.setStrokeJoin(Paint.Join.ROUND);
            mPaint.setStrokeCap(Paint.Cap.ROUND);
            mPaint.setStrokeWidth(25);

            layout.removeView(view);
            view =new MyView(this);
            view.setLayoutParams(new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT));
            view.setBackgroundColor(Color.WHITE);
            layout.addView(view);
        });


        NextLT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NextLT();
            }
        });
        done_btn.setOnClickListener(v->{
            if (view.check()<=0.5){
                showCustomDialog(true);
                success=true;
            }else {
                showCustomDialog(false);
                success=false;
            }
        });
    }

    public void NextLT() {
        if (success) {
            if (mediaPlayer!=null)
            if (mediaPlayer.isPlaying())mediaPlayer.stop();
            if (mediaPlayer2!=null)
            if (mediaPlayer2.isPlaying())mediaPlayer2.stop();

            Intent intent = new Intent(this, WordChallengeActivity.class).putExtra("word", word).putExtra("last",last);
            startActivity(intent);
            finish();
        }else {
            Toast.makeText(this, "الرجاء اكمال هذه المرحله", Toast.LENGTH_SHORT).show();
        }

    }

    public void PreviouseLT() {
        Intent intent = new Intent(this, GameStageActivity.class);
        startActivity(intent);
        finish();

    }


    private void showCustomDialog(boolean status) {
        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);

        //then we will inflate the custom alert dialog xml that we created
        View dialogView;
        if (status) {
            dialogView = LayoutInflater.from(this).inflate(R.layout.correct_dialog, viewGroup, false);
            int resID=getResources().getIdentifier("correct", "raw", getPackageName());

            mediaPlayer = MediaPlayer.create(this,resID);
            mediaPlayer.start();

        }else {
            dialogView = LayoutInflater.from(this).inflate(R.layout.wrong_dialog, viewGroup, false);
            int resID2=getResources().getIdentifier("worng", "raw", getPackageName());

            mediaPlayer2 = MediaPlayer.create(this,resID2);
            mediaPlayer2.start();
        }

        Button btn=dialogView.findViewById(R.id.btn_dialog);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        btn.setOnClickListener(v->{
            alertDialog.dismiss();
        });

    }
    public class MyView extends View {

        private static final float MINP = 0.25f;
        private static final float MAXP = 0.75f;
        private Bitmap mBitmap;
        private Canvas mCanvas;
        private Path mPath;
        private Paint   mBitmapPaint;
        Context context;
        private int h=0;
        private int w=0;

        public MyView(Context c) {
            super(c);
            context=c;
            mPath = new Path();
            mBitmapPaint = new Paint(Paint.DITHER_FLAG);

        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            this.h=h;
            this.w=w;
            mCanvas = new Canvas(mBitmap);
            mPaint.setStyle(Paint.Style.FILL);
            mPaint.setColor(Color.YELLOW);
            mPaint.setTextSize(400);
            mCanvas.drawText(word.getWord(),200,500,mPaint);
            mPaint.setColor(Color.GREEN);
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeWidth(30);
//            mPaint.setStrokeCap(Paint.Cap.ROUND);

        }
        public void reStart(){
            mCanvas.drawColor(0, PorterDuff.Mode.CLEAR);
            mPaint.setStyle(Paint.Style.FILL);
            mPaint.setColor(Color.YELLOW);
            mPaint.setTextSize(300);
            mCanvas.drawText(word.getWord(),500,500,mPaint);
            mPaint.setColor(Color.GREEN);
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeJoin(Paint.Join.ROUND);
            mPaint.setStrokeCap(Paint.Cap.ROUND);
            touch_start(w,h);
            invalidate();

        }
        public double check(){
            int red = 0;
            int green = 0;
            int yellow = 0;
            int orange = 0;
            int other = 0;

            int pixels[] = new int[0];

            Bitmap newBitmap = Bitmap.createScaledBitmap(mBitmap, 100, 100, true);
            for (int i=0;i<mBitmap.getWidth();i++) {
                for (int j = 0; j < mBitmap.getHeight(); j++) {
                    int color = mBitmap.getPixel(i, j);
//                    newBitmap.recycle();

                    int redValue = Color.red(color);
                    int greenValue = Color.green(color);
                    int blueValue = Color.blue(color);

                    float[] hsv = new float[3];
                    Color.RGBToHSV(redValue, greenValue, blueValue, hsv);

                    float hue = hsv[0];
                    float saturation = hsv[1];
                    float value = hsv[2];

                    if (hue > 340 || hue < 20) {
                        red++;
                    } else if (hue > 20 && hue < 45) {
                        orange++;
                    } else if (hue > 45 && hue < 70) {
                        yellow++;
                    } else if (hue > 90 && hue < 140) {
                        green++;
                    } else {
                        other++;
                    }

                }
            }
            Log.e("color", "red" + red + " green" + green+"Yellow "+yellow);

            if (yellow < 25000 && green > 9000 && green < 75000) {
                double d = (double) yellow / (double) green;
                String s = String.valueOf(d).substring(0,2);

                Log.e("res", s + "");
                return Double.parseDouble(s);
            }else return 10.0f;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            canvas.drawBitmap(mBitmap, 0, 0, mBitmapPaint);
            canvas.drawPath(mPath, mPaint);
        }

        private float mX, mY;
        private static final float TOUCH_TOLERANCE = 4;

        private void touch_start(float x, float y) {
            //showDialog();
            mPath.reset();
            mPath.moveTo(x, y);
            mX = x;
            mY = y;

        }
        private void touch_move(float x, float y) {
            float dx = Math.abs(x - mX);
            float dy = Math.abs(y - mY);
            if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
                mPath.quadTo(mX, mY, (x + mX)/2, (y + mY)/2);
                mX = x;
                mY = y;
            }
        }

        private void touch_up() {
            mPath.lineTo(mX, mY);
            // commit the path to our offscreen
            mCanvas.drawPath(mPath, mPaint);
            // kill this so we don't double draw
            mPath.reset();
//            mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
            //mPaint.setMaskFilter(null);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX();
            float y = event.getY();

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touch_start(x, y);
                    invalidate();
                    break;
                case MotionEvent.ACTION_MOVE:

                    touch_move(x, y);
                    invalidate();
                    break;
                case MotionEvent.ACTION_UP:
                    touch_up();
                    invalidate();
                    break;
            }
            return true;
        }
    }
}

