package com.example.alphabet.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alphabet.Letter;
import com.example.alphabet.R;
import com.example.alphabet.Sentence;
import com.example.alphabet.Word;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;

import org.w3c.dom.Text;

import java.io.InputStream;
import java.util.Random;

import androidx.appcompat.app.AppCompatActivity;

import static com.example.alphabet.R.id.letter_challenge_btn_next;
import static com.example.alphabet.R.id.letter_challenge_option1;
import static com.example.alphabet.R.id.letter_challenge_option2;
import static com.example.alphabet.R.id.letter_challenge_option3;
import static com.example.alphabet.R.id.letter_challenge_option4;
import static com.example.alphabet.R.id.letter_challenge_preview;
import static com.example.alphabet.R.id.letter_challenge_sound;

public class WordChallengeActivity extends AppCompatActivity implements View.OnClickListener {

    private MediaPlayer mediaPlayer;
    boolean scusses=false;
    private Word word;
    private boolean last;
    private int num;
    private boolean finall=false;
    private MediaPlayer mediaPlayer2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word_challenge);
        TextView option1=findViewById(letter_challenge_option1);
        TextView option2=findViewById(letter_challenge_option2);
        TextView option3=findViewById(letter_challenge_option3);
        TextView option4=findViewById(letter_challenge_option4);
        Button done_btn=findViewById(letter_challenge_btn_next);
        ImageView letter_tv=findViewById(letter_challenge_preview);
        ImageView letter_sound=findViewById(letter_challenge_sound);
        word = (Word) getIntent().getSerializableExtra("word");
        last = getIntent().getBooleanExtra("last",false);
        if (getIntent().getBooleanExtra("final",false)){
            finall=getIntent().getBooleanExtra("final",false);
            num=getIntent().getIntExtra("num",0);
        }
        int rid = getResources()
                .getIdentifier(word.getWord_img(),"raw", getPackageName());
        Resources res = getResources();
        InputStream in = res.openRawResource(rid);
        Drawable image = Drawable.createFromStream(in, word.getWord_img());
        letter_tv.setImageDrawable(image);
        letter_sound.setOnClickListener(v->{
            int resID2=getResources().getIdentifier(word.getWord_sound(), "raw", getPackageName());

            mediaPlayer = MediaPlayer.create(this,resID2);
            mediaPlayer.start();
        });
        option1.setOnClickListener(this);
        option2.setOnClickListener(this);
        option3.setOnClickListener(this);
        option4.setOnClickListener(this);
        if (word.getWord_correct()==1){
            option1.setText(word.getWord_miss());
            option2.setText("ك");
            option3.setText("ش");
            option4.setText("ي");
        }else if (word.getWord_correct()==2){
            option1.setText("ث");
            option2.setText(word.getWord_miss());
            option3.setText("ش");
            option4.setText("ي");
        }else if (word.getWord_correct()==3){
            option1.setText("ث");
            option2.setText("ف");
            option4.setText("د");
            option3.setText(word.getWord_miss());
        }else if (word.getWord_correct()==4){
            option1.setText("ث");
            option2.setText("ف");
            option3.setText("د");
            option4.setText(word.getWord_miss());
        }
        if (word.getWord_correct()==0)
            scusses=true;
        done_btn.setOnClickListener(v->{

            if (!scusses) {
                Toast.makeText(this, "الرجاء اختيار الاجابه الصحيحيه", Toast.LENGTH_SHORT).show();
                return;
            }
            Database database=new Database(getApplicationContext());

            if (finall){

                    num++;
                    Random random=new Random();
                    if(num<7) {
                        int i = random.nextInt(11);
                        Word word = database.getWord(i);
                        Intent intent = new Intent(this, WordChallengeActivity.class).putExtra("word", word).putExtra("final", true).putExtra("num", num);
                        startActivity(intent);
                        finish();
                    }else {
                        int i = random.nextInt(11);
                        Sentence sentence = database.getSentence(i);
                        Intent intent = new Intent(this, SentenceChallengeActivity.class).putExtra("sentence", sentence).putExtra("final", true).putExtra("num", num);
                        startActivity(intent);
                        finish();
                    }

            }else {
                if (database.getWordsStatus(SettingUtility.getId(getApplicationContext()), word.getId())==-1)
                    database.insertWordUser(word.getId(),SettingUtility.getId(getApplicationContext()),1);
                database.updateWordStatus(word.getId(), SettingUtility.getId(getApplicationContext()));
                if (last)
                    database.updateUserStage(2, SettingUtility.getId(getApplicationContext()));
                Intent intent = new Intent(this, WordsActivity.class);
                startActivity(intent);
                finish();
            }
        });

        int resID3=getResources().getIdentifier(word.getWord_sound(), "raw", getPackageName());

        mediaPlayer = MediaPlayer.create(this,resID3);
        mediaPlayer.start();
    }








    private void showCustomDialog(boolean status) {
        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);

        //then we will inflate the custom alert dialog xml that we created
        View dialogView;
        if (status) {
            dialogView = LayoutInflater.from(this).inflate(R.layout.correct_dialog, viewGroup, false);
            int resID=getResources().getIdentifier("correct", "raw", getPackageName());

            mediaPlayer = MediaPlayer.create(this,resID);
            mediaPlayer.start();
            if (last){
                TextView text=dialogView.findViewById(R.id.reword);
                text.setText("تهانينا لقد تم فتح شخصيه كرتونيه جديده يمكن الانتقال لواجهه الشخصيات");
            }
        }else {
            dialogView = LayoutInflater.from(this).inflate(R.layout.wrong_dialog, viewGroup, false);
            int resID2=getResources().getIdentifier("worng", "raw", getPackageName());

            mediaPlayer2 = MediaPlayer.create(this,resID2);
            mediaPlayer2.start();
        }

        Button btn=dialogView.findViewById(R.id.btn_dialog);


        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        btn.setOnClickListener(v->{
            alertDialog.dismiss();
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.letter_challenge_option1:
                if (word.getWord_correct()==1){
                    scusses=true;
                    showCustomDialog(true);
                    break;
                }else {
                    scusses = false;
                    showCustomDialog(false);
                    break;
                }
            case R.id.letter_challenge_option2:
                if (word.getWord_correct()==2){
                    scusses=true;
                    showCustomDialog(true);
                    break;
                }else {
                    scusses = false;
                    showCustomDialog(false);
                    break;
                }
            case R.id.letter_challenge_option3:
                if (word.getWord_correct()==3){
                    scusses=true;
                    showCustomDialog(true);
                    break;
                }else {
                    scusses = false;
                    showCustomDialog(false);
                    break;
                }
            case R.id.letter_challenge_option4:
                if (word.getWord_correct()==4){
                    scusses=true;
                    showCustomDialog(true);
                    break;
                }else {
                    scusses = false;
                    showCustomDialog(false);
                    break;
                }

        }

    }

}
