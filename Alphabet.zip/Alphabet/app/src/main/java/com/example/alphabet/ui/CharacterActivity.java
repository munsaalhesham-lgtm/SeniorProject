package com.example.alphabet.ui;


import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.alphabet.R;
import com.example.alphabet.User;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;

import androidx.appcompat.app.AppCompatActivity;

public class CharacterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character);
        ImageView c1=findViewById(R.id.c_selected);
        ImageView c2=findViewById(R.id.c_selected2);
        ImageView c3=findViewById(R.id.c_selected3);
        ImageView c4=findViewById(R.id.c_selected4);
        ImageView c5=findViewById(R.id.c_selected5);
        ImageView c6=findViewById(R.id.c_selected6);

        Database database=new Database(getApplicationContext());
        User user=database.getCurrentUser(SettingUtility.getEmail(getApplicationContext()));
        if (user.getStage()==1){
            c3.setBackgroundColor(getResources().getColor(R.color.colortrans));
        }else if (user.getStage()==2){
            c3.setBackgroundColor(getResources().getColor(R.color.colortrans));
            c4.setBackgroundColor(getResources().getColor(R.color.colortrans));
        }else if (user.getStage()==3){
            c3.setBackgroundColor(getResources().getColor(R.color.colortrans));
            c4.setBackgroundColor(getResources().getColor(R.color.colortrans));
            c5.setBackgroundColor(getResources().getColor(R.color.colortrans));
            c6.setBackgroundColor(getResources().getColor(R.color.colortrans));
        }
        c1.setOnClickListener(v->{
            SettingUtility.setImage(this,"c_one");
            Toast.makeText(this, "تم اختيار الشخصيه", Toast.LENGTH_SHORT).show();

        });
        c2.setOnClickListener(v->{
            Toast.makeText(this, "تم اختيار الشخصيه", Toast.LENGTH_SHORT).show();
            SettingUtility.setImage(this,"c_tow");

        });
        c3.setOnClickListener(v->{
            if (user.getStage()>=1) {
                Toast.makeText(this, "تم اختيار الشخصيه", Toast.LENGTH_SHORT).show();
                SettingUtility.setImage(this, "c_tow");
            }

        });
        c4.setOnClickListener(v->{
            if (user.getStage()>=2) {
                Toast.makeText(this, "تم اختيار الشخصيه", Toast.LENGTH_SHORT).show();
                SettingUtility.setImage(this, "c_tow");
            }
        });
        c5.setOnClickListener(v->{
            if (user.getStage()>=3) {
                Toast.makeText(this, "تم اختيار الشخصيه", Toast.LENGTH_SHORT).show();
                SettingUtility.setImage(this, "c_tow");
            }

        });
        c6.setOnClickListener(v->{
            if (user.getStage()>=3) {
                Toast.makeText(this, "تم اختيار الشخصيه", Toast.LENGTH_SHORT).show();
                SettingUtility.setImage(this, "c_tow");
            }

        });

    }
}
