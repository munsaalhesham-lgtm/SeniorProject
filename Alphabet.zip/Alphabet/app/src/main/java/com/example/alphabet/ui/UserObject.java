package com.example.alphabet.ui;

public class UserObject {
    private int UserId =1;
    private String UserName ="";
    private String UserPassword ="";
    private int UserBirthdate=0;
    private String UserEmail = "";

    public void setUserId(int userId) {
        UserId = userId;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public void setUserPassword(String userPassword) {
        UserPassword = userPassword;
    }

    public void setUserBirthdate(int userBirthdate) {
        UserBirthdate = userBirthdate;
    }

    public void setUserEmail(String userEmail) {
        UserEmail = userEmail;
    }

    public int getUserId() {
        return UserId;
    }

    public String getUserName() {
        return UserName;
    }

    public String getUserPassword() {
        return UserPassword;
    }

    public int getUserBirthdate() {
        return UserBirthdate;
    }

    public String getUserEmail() {
        return UserEmail;
    }
}
