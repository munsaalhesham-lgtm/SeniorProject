package com.example.alphabet.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.alphabet.R;
import com.example.alphabet.Sentence;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;
import com.example.alphabet.ui.adapters.SentenceAdapter;

import java.util.ArrayList;

public class SentenceActivity extends AppCompatActivity {
private Button previouseS;
    private Button NextS;
    private RecyclerView wordList;
    private ArrayList<Sentence> sentences =new ArrayList<>();
    private SentenceAdapter sentenceAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sentence);
      NextS=(Button)findViewById(R.id.NextS);
      previouseS=(Button)findViewById(R.id.previouseS);
        wordList=findViewById(R.id.word_list);
        Database database=new Database(getApplicationContext());
        sentences =database.getSentences(SettingUtility.getId(getApplicationContext()));
        if (sentences.size()==0){
            database.insertSentence("waves_sentence",".... البحر عالية","أمواج البحر عالية",1,"أمواج");
            database.insertSentence("door_sentence",".... الغرفة مقفل","باب الغرفة مقفل",2,"باب");
            database.insertSentence("guard_sentence","للحديقة ....","للحديقة حارس",3,"حارس");
            database.insertSentence("banana_sentence","ال .... أصفر","الموز أصفر",4,"موز");
            database.insertSentence("crown_sentence",".... الملك لامع","تاج الملك لامع",1,"تاج");
            database.insertSentence("roses_sentence","ال .... حمراء","الورود حمراء",2,"ورود");
            database.insertSentence("boy_sentence","خالد .... مهذب","خالد ولد مهذب",3,"ولد");
            database.insertSentence("lion_sentence","ال .... مفترس","الاسد مفترس",4,"اسد");
            database.insertSentence("bicycle_sentence","اشتريت ....","اشتريت دراجة",1,"دراجة");
            sentences =database.getSentences(SettingUtility.getId(getApplicationContext()));
        }
        sentenceAdapter =new SentenceAdapter(sentences,this);
        LinearLayoutManager gridLayoutManager=new LinearLayoutManager(this);
        wordList.setAdapter(sentenceAdapter);
        wordList.setLayoutManager(gridLayoutManager);

        NextS.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              NextS();
          }
      });
      previouseS.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              previouseS();
          }
      });

    }
  public void NextS(){
      Intent intent = new Intent(this , SntenceTutorialActivity.class);
      startActivity(intent);
      finish();

  }
  public void previouseS(){
        Intent intent=new Intent(this, GameStageActivity.class);
      startActivity(intent);
      finish();

  }
}
