package com.example.alphabet.ui;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.alphabet.Letter;
import com.example.alphabet.R;
import com.example.alphabet.User;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;

import java.util.Random;

import androidx.appcompat.app.AppCompatActivity;

public class GameStageActivity extends AppCompatActivity {
    private Button Letter;
    private Button Word;
    private Button Sentence;
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_stage_interface);

        Letter =(Button) findViewById(R.id.Letter);
        Word =(Button) findViewById(R.id.Word);
        Sentence = (Button) findViewById(R.id.Sentence);
        Button test = (Button) findViewById(R.id.FinalTest);
        ImageView lock1=findViewById(R.id.lock1);
        ImageView lock2=findViewById(R.id.lock2);
        ImageView lock3=findViewById(R.id.lock3);
        Database database=new Database(getApplicationContext());
        User user=database.getCurrentUser(SettingUtility.getEmail(getApplicationContext()));
        Log.e("stage",user.getStage()+"");
        if (user.getStage()==1){
            lock1.setVisibility(View.GONE);
            Sentence.setBackground(getDrawable(R.drawable.shapebutton2));
            test.setBackground(getDrawable(R.drawable.shapebutton2));

        }else if (user.getStage()==2){
            lock2.setVisibility(View.GONE);
            test.setBackground(getDrawable(R.drawable.shapebutton2));
        }else if (user.getStage()==3){
            lock3.setVisibility(View.GONE);
        }else {
            Word.setBackground(getDrawable(R.drawable.shapebutton2));
            Sentence.setBackground(getDrawable(R.drawable.shapebutton2));
            test.setBackground(getDrawable(R.drawable.shapebutton2));

        }

        int resID=getResources().getIdentifier("game_stages", "raw", getPackageName());

        mediaPlayer = MediaPlayer.create(this,resID);
        mediaPlayer.start();
        Letter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Letter();

            }
        });

        Word.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (user.getStage()==1)
                Word();

            }
        });

        Sentence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (user.getStage()==2)
                Sentence();

            }
        });
        test.setOnClickListener(v->{
//            if (user.getStage()==3) {
                Random random=new Random();
                int i=random.nextInt(27);
                Letter letter=database.getLetter(i);
                Intent intent = new Intent(this, LetterChallengeActivity.class).putExtra("letter",letter).putExtra("final",true).putExtra("num",1);
                startActivity(intent);
//            }
        });
    }

    public void Sentence(){

        Intent intent=new Intent(this, SentenceActivity.class);
        startActivity(intent);
    }
    public void Word(){
        Intent intent = new Intent (this, WordsActivity.class);
        startActivity(intent);
    }
    public void Letter(){
        Intent intent = new Intent (this, LettersActivity.class);
        startActivity(intent);
    }
}

