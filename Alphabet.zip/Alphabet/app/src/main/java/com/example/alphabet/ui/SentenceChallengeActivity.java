package com.example.alphabet.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alphabet.R;
import com.example.alphabet.Sentence;
import com.example.alphabet.Word;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;

import java.io.InputStream;
import java.util.Random;

import static com.example.alphabet.R.id.letter_challenge_btn_next;
import static com.example.alphabet.R.id.letter_challenge_option1;
import static com.example.alphabet.R.id.letter_challenge_option2;
import static com.example.alphabet.R.id.letter_challenge_option3;
import static com.example.alphabet.R.id.letter_challenge_option4;
import static com.example.alphabet.R.id.letter_challenge_preview;
import static com.example.alphabet.R.id.letter_challenge_sound;

public class SentenceChallengeActivity extends AppCompatActivity implements View.OnClickListener {


    private MediaPlayer mediaPlayer;
    boolean scusses=false;
    private Sentence sentence;
    private boolean last;
    private int num;
    private boolean finall=false;
    private MediaPlayer mediaPlayer2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sentence_challenge);
        TextView option1=findViewById(letter_challenge_option1);
        TextView option2=findViewById(letter_challenge_option2);
        TextView option3=findViewById(letter_challenge_option3);
        TextView option4=findViewById(letter_challenge_option4);
        Button done_btn=findViewById(letter_challenge_btn_next);
        TextView letter_tv=findViewById(letter_challenge_preview);
        ImageView letter_sound=findViewById(letter_challenge_sound);
        sentence = (Sentence) getIntent().getSerializableExtra("sentence");
        last = getIntent().getBooleanExtra("last",false);

        if (getIntent().getBooleanExtra("final",false)){
            finall=getIntent().getBooleanExtra("final",false);
            num=getIntent().getIntExtra("num",0);
        }

        letter_tv.setText(sentence.getSentence_img());
        letter_sound.setOnClickListener(v->{
            int resID2=getResources().getIdentifier(sentence.getSentence_sound(), "raw", getPackageName());

            mediaPlayer = MediaPlayer.create(this,resID2);
            mediaPlayer.start();
        });
        option1.setOnClickListener(this);
        option2.setOnClickListener(this);
        option3.setOnClickListener(this);
        option4.setOnClickListener(this);
        Database database=new Database(getApplicationContext());
        Random r=new Random();
        int i1= r.nextInt(13);
        int i2= r.nextInt(13);
        int i3= r.nextInt(13);
        int i4= r.nextInt(13);
        Word word1=database.getWord(i1);
        Word word2=database.getWord(i2);
        Word word3=database.getWord(i3);
        Word word4=database.getWord(i4);
        if (sentence.getSentence_correct()==1){
            option1.setText(sentence.getSentence_miss());
            option2.setText(word2.getWord());
            option3.setText(word3.getWord());
            option4.setText(word4.getWord());
        }else if (sentence.getSentence_correct()==2){
            option2.setText(sentence.getSentence_miss());
            option3.setText(word3.getWord());
            option1.setText(word1.getWord());
            option4.setText(word4.getWord());
        }else if (sentence.getSentence_correct()==3){
            option1.setText(word1.getWord());
            option4.setText(word4.getWord());
            option2.setText(word3.getWord());
            option3.setText(sentence.getSentence_miss());
        }else if (sentence.getSentence_correct()==4){
            option1.setText(word1.getWord());
            option3.setText(word3.getWord());
            option2.setText(word2.getWord());
            option4.setText(sentence.getSentence_miss());
        }
        if (sentence.getSentence_correct()==0)
            scusses=true;
        done_btn.setOnClickListener(v->{
            if (!scusses) {
                Toast.makeText(this, "الرجاء اختيار الاجابه الصحيحيه", Toast.LENGTH_SHORT).show();
                return;
            }

            if (finall){

                num++;
                Random random=new Random();
                if(num<10) {
                    int i = random.nextInt(11);
                    Sentence letter = database.getSentence(i);
                    Intent intent = new Intent(this, SentenceChallengeActivity.class).putExtra("sentence", letter).putExtra("final", true).putExtra("num", num);
                    startActivity(intent);
                    finish();
                }else {
                    Toast.makeText(this, "تم اجتياز الاختبار النهائي بنجاح", Toast.LENGTH_SHORT).show();
                    finish();
                }

            }else {
                if (database.getSentenceStatus(SettingUtility.getId(getApplicationContext()), sentence.getId())==-1)
                    database.insertSenteceUser(sentence.getId(),SettingUtility.getId(getApplicationContext()),1);
                database.updateSentenceStatus(sentence.getId(), SettingUtility.getId(getApplicationContext()));

                if (last)
                    database.updateUserStage(3, SettingUtility.getId(getApplicationContext()));
                Intent intent = new Intent(this, SentenceActivity.class);
                startActivity(intent);
                finish();
            }
        });
        int resID3=getResources().getIdentifier(sentence.getSentence_sound(), "raw", getPackageName());

        mediaPlayer = MediaPlayer.create(this,resID3);
        mediaPlayer.start();
    }








    private void showCustomDialog(boolean status) {
        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);

        //then we will inflate the custom alert dialog xml that we created
        View dialogView;
        if (status) {
            dialogView = LayoutInflater.from(this).inflate(R.layout.correct_dialog, viewGroup, false);
            int resID=getResources().getIdentifier("correct", "raw", getPackageName());
            if (last){
                TextView text=dialogView.findViewById(R.id.reword);
                text.setText("تهانينا لقد تم فتح شخصيه كرتونيه جديده يمكن الانتقال لواجهه الشخصيات");
            }
            mediaPlayer = MediaPlayer.create(this,resID);
            mediaPlayer.start();

        }else {
            dialogView = LayoutInflater.from(this).inflate(R.layout.wrong_dialog, viewGroup, false);
            int resID2=getResources().getIdentifier("worng", "raw", getPackageName());

            mediaPlayer2 = MediaPlayer.create(this,resID2);
            mediaPlayer2.start();
        }

        Button btn=dialogView.findViewById(R.id.btn_dialog);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        btn.setOnClickListener(v->{
            alertDialog.dismiss();
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.letter_challenge_option1:
                if (sentence.getSentence_correct()==1){
                    scusses=true;
                    showCustomDialog(true);
                    break;
                }else {
                    scusses = false;
                    showCustomDialog(false);
                    break;
                }
            case R.id.letter_challenge_option2:
                if (sentence.getSentence_correct()==2){
                    scusses=true;
                    showCustomDialog(true);
                    break;
                }else {
                    scusses = false;
                    showCustomDialog(false);
                    break;
                }
            case R.id.letter_challenge_option3:
                if (sentence.getSentence_correct()==3){
                    scusses=true;
                    showCustomDialog(true);
                    break;
                }else {
                    scusses = false;
                    showCustomDialog(false);
                    break;
                }
            case R.id.letter_challenge_option4:
                if (sentence.getSentence_correct()==4){
                    scusses=true;
                    showCustomDialog(true);
                    break;
                }else {
                    scusses = false;
                    showCustomDialog(false);
                    break;
                }

        }

    }
}
