package com.example.alphabet;

import java.io.Serializable;

public class Word implements Serializable {
    private int id;
    private String word_sound;
    private String word_img;
    private String word;
    private String word_miss;
    private int word_correct;

    public Word(int id, String word_sound, String word_img, String word, int word_correct,String word_miss) {
        this.id = id;
        this.word_sound = word_sound;
        this.word_img = word_img;
        this.word = word;
        this.word_correct = word_correct;
        this.word_miss=word_miss;
    }

    public String getWord_miss() {
        return word_miss;
    }

    public void setWord_miss(String word_miss) {
        this.word_miss = word_miss;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWord_sound() {
        return word_sound;
    }

    public void setWord_sound(String word_sound) {
        this.word_sound = word_sound;
    }

    public String getWord_img() {
        return word_img;
    }

    public void setWord_img(String word_img) {
        this.word_img = word_img;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public int getWord_correct() {
        return word_correct;
    }

    public void setWord_correct(int word_correct) {
        this.word_correct = word_correct;
    }
}
