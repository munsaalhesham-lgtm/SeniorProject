package com.example.alphabet.ui;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.alphabet.R;
import com.example.alphabet.User;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText edittxtEmail_Name, password;
    private Button LogIn;
    private Database database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        LogIn = (Button) findViewById(R.id.btnLogIn);
        edittxtEmail_Name=findViewById(R.id.editLogInEmail_name);
        password=findViewById(R.id.editLogInPassword);
        database=new Database(this);
        LogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EnterGame();
            }
        });
        init_events();
        int resID=getResources().getIdentifier("main_interface2", "raw", getPackageName());

        MediaPlayer mediaPlayer = MediaPlayer.create(this,resID);
        mediaPlayer.start();

    }
    //connecting xml to java views and other connections

    private void init_events() {
        LogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {                // check fileds aren't empty
                if (edittxtEmail_Name.getText().toString().equals("")) {
                    Toast.makeText(LoginActivity.this, " خانة ألإسم او البريد فارغة ", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.getText().toString().equals("")) {
                    Toast.makeText(LoginActivity.this, "خانة كلمة السر فارغة", Toast.LENGTH_SHORT).show();
                    return;
                }
                Log.e("emila",edittxtEmail_Name.getText().toString());
                User user=database.getCurrentUser(edittxtEmail_Name.getText().toString().trim());
                if (user==null){
                    Toast.makeText(LoginActivity.this, "email not found", Toast.LENGTH_SHORT).show();
                }else {
                    if (!user.getPassword().equals(password.getText().toString())){
                        Toast.makeText(LoginActivity.this, "password incorrect", Toast.LENGTH_SHORT).show();
                    }else {

                        SettingUtility.setEmail(LoginActivity.this,edittxtEmail_Name.getText().toString());
                        SettingUtility.setId(LoginActivity.this,user.getId());
                        SettingUtility.setUserName(LoginActivity.this,user.getName());
                        SettingUtility.setActivited(LoginActivity.this,true);
                        Toast.makeText(LoginActivity.this, "logged in successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
            }
        });
    }

    public void EnterGame() {

        Intent intent = new Intent(this, GameStageActivity.class);
        startActivity(intent);
    }
}
