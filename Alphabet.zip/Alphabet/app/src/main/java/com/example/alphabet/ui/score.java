package com.example.alphabet.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.alphabet.R;

public class score extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
    }
}
