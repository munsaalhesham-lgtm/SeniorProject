package com.example.alphabet.ui.adapters;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alphabet.R;
import com.example.alphabet.Word;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;
import com.example.alphabet.ui.WordTutorialActivity;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class WordAdapter extends RecyclerView.Adapter<SentenceHodler> {
    ArrayList<Word> words;
    Activity activity;
    private MediaPlayer mediaPlayer;
    Database database;
    public WordAdapter(ArrayList<Word> words, Activity activity) {
        this.words = words;
        this.activity = activity;
        this.database=new Database(activity);
    }

    @NonNull
    @Override
    public SentenceHodler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_letter,parent,false);
        return  new SentenceHodler(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SentenceHodler holder, int position) {
        holder.l_text.setText(words.get(position).getWord());

        if (position!=0){
            int status=database.getWordsStatus(SettingUtility.getId(activity),words.get(position-1).getId());
            if (status==-1||status==0){
                holder.l_img.setBackground(activity.getDrawable(R.drawable.shapebutton2));
            }
        }
        holder.l_img.setOnClickListener(v->{
            if (position!=0){
                int status=database.getWordsStatus(SettingUtility.getId(activity), words.get(position-1).getId());
                if (status==-1||status==0){
                    Toast.makeText(activity, "هذه المرحله لازالت مقفله", Toast.LENGTH_SHORT).show();
                    int resID=activity.getResources().getIdentifier("stage_unavailable", "raw", activity.getPackageName());

                    mediaPlayer = MediaPlayer.create(activity,resID);
                    mediaPlayer.start();

                }else {
                    Intent intent=new Intent(activity, WordTutorialActivity.class).putExtra("word", words.get(position));
                    if (position==words.size()){
                        intent.putExtra("last",true);
                    }
                    activity.startActivity(intent);
                    activity.finish();
                }
            }else {
                activity.startActivity(new Intent(activity, WordTutorialActivity.class).putExtra("word", words.get(position)));
                activity.finish();
            }
        });
    }

    @Override
    public int getItemCount() {
        return words.size();
    }
}

class WordHodler extends RecyclerView.ViewHolder {

    ImageView l_img;
    TextView l_text;
    public WordHodler(@NonNull View itemView) {
        super(itemView);
        l_img=itemView.findViewById(R.id.letter_img);
        l_text=itemView.findViewById(R.id.letter_l);
    }
}
