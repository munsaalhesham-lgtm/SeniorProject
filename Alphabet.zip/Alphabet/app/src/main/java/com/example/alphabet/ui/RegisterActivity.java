package com.example.alphabet.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.alphabet.R;
import com.example.alphabet.Tools;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private String img64;
    private int REQUEST_IMAGE_CAPTURE=1 ;
    private EditText edittxtName ,
            edittxtBirthdate ,
            edittxtEmail ,
            edittxtPassord1,
            edittxtPassword2 ,
              et ;
    private ImageView c_one;
    private ImageView c_tow;

    private Button   imgeProfile ,Rigester;

    Database database;
    private String edittxtFavCh="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        database = new Database(this);
        init_views();
        init_activity();
        int resID=getResources().getIdentifier("main_interface2", "raw", getPackageName());

        MediaPlayer mediaPlayer = MediaPlayer.create(this,resID);
        mediaPlayer.start();

    }





    void init_views(){
        // edit text

        edittxtName = findViewById(R.id.edittxtName);
        edittxtEmail = findViewById(R.id.editEmail);
        edittxtBirthdate = findViewById(R.id.edittxtBirthdate);
        edittxtPassord1 = findViewById(R.id.edittxtPassword1);
        edittxtPassword2 = findViewById(R.id.edittxtPassword2);
        c_one = findViewById(R.id.c_selected);
        c_tow = findViewById(R.id.c_selected2);
        imgeProfile = findViewById(R.id.buttonViewProfile);
        et =findViewById(R.id.edittxtBirthdate);
        // button
        Rigester = findViewById(R.id.buttonRigester);
      //  database =new Database(RegisterActivity.this);

    }
    //
    void init_activity(){

        imgeProfile.setOnClickListener(v->{
            Intent intent = new Intent(Intent.ACTION_PICK,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(Intent.createChooser(intent, "Select Picture"),REQUEST_IMAGE_CAPTURE);
        });

        c_one.setOnClickListener(v->{
            edittxtFavCh="c_one";
            Toast.makeText(this, "تم اختيار الشخصيه", Toast.LENGTH_SHORT).show();
        });

        c_tow.setOnClickListener(v->{
            edittxtFavCh="c_tow";
            Toast.makeText(this, "تم اختيار الشخصيه", Toast.LENGTH_SHORT).show();
        });

        Rigester.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // casting edittext values into an int for arg handling
                String setTxtFormat = et.getText().toString();
                int birthdateIntFormat =new Integer(setTxtFormat).intValue();
                // checking if all feilds are not empty
                if(edittxtEmail.getText().toString().equals("")){
                    Toast.makeText(RegisterActivity.this, "خانة البريد فارغة", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(edittxtName.getText().toString().equals("")){
                    Toast.makeText(RegisterActivity.this,"خانة الاسم فارغة", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(edittxtBirthdate.getText().toString().equals("")){
                    Toast.makeText(RegisterActivity.this,"خانة العمر فارغة", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(edittxtFavCh.isEmpty()){
                    Toast.makeText(RegisterActivity.this,"الرجاء اختيار الشخصيه", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(edittxtPassord1.getText().toString().equals("")){
                    Toast.makeText(RegisterActivity.this," كلمة السر فارغة", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(edittxtPassword2.getText().toString().equals("")){
                    Toast.makeText(RegisterActivity.this,"تاكيد كلمة السر فارغة", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(img64==null){
                    Toast.makeText(RegisterActivity.this,"الرجاء اختيار صورة الملف الشخصي", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!edittxtPassord1.getText().toString().equals(edittxtPassword2.getText().toString())){
                    Toast.makeText(RegisterActivity.this,"كلمة المرور و تاكيد كلمة المرور غير متطابقة", Toast.LENGTH_SHORT).show();
                    return;
                }
                // sending registry info into the database
                long i = database.registerUser(edittxtName.getText().toString(),
                        edittxtEmail.getText().toString(),
                        edittxtPassord1.getText().toString(),
                        birthdateIntFormat,img64);
                if ( i > 0){
                    Toast.makeText(RegisterActivity.this, "تم التسجيل", Toast.LENGTH_SHORT).show();
                    SettingUtility.setEmail(RegisterActivity.this,edittxtEmail.getText().toString());
                    SettingUtility.setId(RegisterActivity.this, (int) i);
                    SettingUtility.setUserName(RegisterActivity.this,edittxtName.getText().toString());
                    SettingUtility.setImage(RegisterActivity.this,edittxtFavCh);
                    SettingUtility.setActivited(RegisterActivity.this,true);
                    finish();
                }else {
                    Toast.makeText(RegisterActivity.this, " خطا", Toast.LENGTH_SHORT).show();
                }
            }
        }));


    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                try {
                    Uri currImageURI = data.getData();

                    InputStream imageStream = null;
                    if (currImageURI != null) {
                        imageStream =getContentResolver().openInputStream(currImageURI);
                        Bitmap yourSelectedImage = BitmapFactory.decodeStream(imageStream);
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        yourSelectedImage.compress(Bitmap.CompressFormat.JPEG, 70,bos);
                        InputStream in = new ByteArrayInputStream(bos.toByteArray());
                        yourSelectedImage = BitmapFactory.decodeStream(in);
                        img64 = Tools.encodeTobase64(yourSelectedImage);
                    }


                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }



            }
        }
        super.onActivityResult(requestCode,resultCode,data);
    }

}
