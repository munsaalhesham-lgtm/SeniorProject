package com.example.alphabet.ui.adapters;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alphabet.R;
import com.example.alphabet.Sentence;
import com.example.alphabet.database.Database;
import com.example.alphabet.database.SettingUtility;
import com.example.alphabet.ui.SntenceTutorialActivity;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SentenceAdapter extends RecyclerView.Adapter<SentenceHodler> {
    ArrayList<Sentence> sentences;
    Activity activity;
    private MediaPlayer mediaPlayer;
    Database database;
    public SentenceAdapter(ArrayList<Sentence> sentences, Activity activity) {
        this.sentences = sentences;
        this.activity = activity;
        this.database=new Database(activity);
    }

    @NonNull
    @Override
    public SentenceHodler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_sentence,parent,false);
        return  new SentenceHodler(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SentenceHodler holder, int position) {
        holder.l_text.setText(sentences.get(position).getSentenc());
        if (position!=0){
            int status=database.getSentenceStatus(SettingUtility.getId(activity),sentences.get(position-1).getId());
            if (status==-1||status==0){
                holder.l_img.setBackground(activity.getDrawable(R.drawable.round_shape2));
            }
        }
        holder.l_img.setOnClickListener(v->{
            if (position!=0){
                int status=database.getSentenceStatus(SettingUtility.getId(activity), sentences.get(position-1).getId());
                if (status==-1||status==0){
                    Toast.makeText(activity, "هذه المرحله لازالت مقفله", Toast.LENGTH_SHORT).show();
                    int resID=activity.getResources().getIdentifier("stage_unavailable", "raw", activity.getPackageName());

                    mediaPlayer = MediaPlayer.create(activity,resID);
                    mediaPlayer.start();

                }else {
                    Intent intent=new Intent(activity, SntenceTutorialActivity.class).putExtra("sentence", sentences.get(position));
                    if (position==sentences.size()){
                        intent.putExtra("last",true);
                    }
                    activity.startActivity(intent);
                    activity.finish();
                }
            }else {
                activity.startActivity(new Intent(activity, SntenceTutorialActivity.class).putExtra("sentence", sentences.get(position)));
                activity.finish();
            }
        });
    }

    @Override
    public int getItemCount() {
        return sentences.size();
    }
}

class SentenceHodler extends RecyclerView.ViewHolder {

    ImageView l_img;
    TextView l_text;
    public SentenceHodler(@NonNull View itemView) {
        super(itemView);
        l_img=itemView.findViewById(R.id.letter_img);
        l_text=itemView.findViewById(R.id.letter_l);
    }
}
